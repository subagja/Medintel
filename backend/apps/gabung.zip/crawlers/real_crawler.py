from dataclasses import dataclass, field
from typing import Any

from django.utils import timezone

from apps.ingestion.services import ingest_article
from apps.sources.models import (
    Source,
    SourceSeedUrl,
)
from apps.sources.services import (
    check_source_crawl_readiness,
    normalize_url,
    validate_source_url,
)

from .html_parser import (
    discover_article_links,
    parse_article_html,
)
from .http_client import (
    CrawlerHttpClient,
    CrawlerHttpError,
    RobotsDeniedError,
)


MINIMUM_ARTICLE_CONTENT_LENGTH = 200


@dataclass
class CrawlSourceResult:
    source: Source
    seed_pages_processed: int = 0
    links_discovered: int = 0
    links_allowed: int = 0
    articles_fetched: int = 0
    articles_created: int = 0
    articles_duplicate: int = 0
    articles_rejected: int = 0
    errors: list[dict[str, Any]] = field(
        default_factory=list
    )


def unpack_ingestion_result(
    ingestion_result,
) -> tuple[Any, bool]:
    if isinstance(
        ingestion_result,
        tuple,
    ):
        if len(ingestion_result) >= 2:
            return (
                ingestion_result[0],
                bool(ingestion_result[1]),
            )

    created = getattr(
        ingestion_result,
        "created",
        False,
    )

    article = getattr(
        ingestion_result,
        "article",
        ingestion_result,
    )

    return article, bool(created)


def add_error(
    result: CrawlSourceResult,
    *,
    url: str,
    stage: str,
    error: Exception | str,
) -> None:
    result.errors.append(
        {
            "url": url,
            "stage": stage,
            "error": str(error),
        }
    )


def ingest_parsed_article(
    *,
    source: Source,
    requested_url: str,
    final_url: str,
    parsed_article,
):
    metadata = {
        **parsed_article.metadata,
        "requested_url": requested_url,
        "final_url": final_url,
        "crawler": "generic_html",
    }

    payload = {
        "source": source,
        "source_name": source.name,
        "source_url": requested_url,
        "original_url": requested_url,
        "resolved_url": (
            parsed_article.canonical_url
            or final_url
        ),
        "title": parsed_article.title,
        "content": parsed_article.content,
        "content_text": parsed_article.content,
        "published_at": parsed_article.published_at,
        "author": parsed_article.author,
        "metadata": metadata,
    }

    return ingest_article(
        payload
    )


def crawl_direct_article(
    *,
    source: Source,
    client: CrawlerHttpClient,
    article_url: str,
    result: CrawlSourceResult,
) -> bool:
    validation = validate_source_url(
        source,
        article_url,
    )

    if not validation.is_valid:
        result.articles_rejected += 1

        add_error(
            result,
            url=article_url,
            stage="url_validation",
            error=validation.reason,
        )

        return False

    normalized_url = (
        validation.normalized_url
    )

    try:
        page = client.get_html(
            normalized_url
        )
    except (
        CrawlerHttpError,
        RobotsDeniedError,
    ) as exc:
        add_error(
            result,
            url=normalized_url,
            stage="article_fetch",
            error=exc,
        )

        return False

    final_validation = validate_source_url(
        source,
        page.final_url,
    )

    if not final_validation.is_valid:
        result.articles_rejected += 1

        add_error(
            result,
            url=page.final_url,
            stage="redirect_validation",
            error=final_validation.reason,
        )

        return False

    parsed_article = parse_article_html(
        html=page.text,
        page_url=page.final_url,
    )

    if not parsed_article.title:
        result.articles_rejected += 1

        add_error(
            result,
            url=page.final_url,
            stage="article_parse",
            error="Judul artikel tidak ditemukan.",
        )

        return False

    if (
        len(parsed_article.content)
        < MINIMUM_ARTICLE_CONTENT_LENGTH
    ):
        result.articles_rejected += 1

        add_error(
            result,
            url=page.final_url,
            stage="article_parse",
            error=(
                "Isi artikel terlalu pendek atau "
                "tidak berhasil diekstrak."
            ),
        )

        return False

    try:
        ingestion_result = ingest_parsed_article(
            source=source,
            requested_url=normalized_url,
            final_url=page.final_url,
            parsed_article=parsed_article,
        )

        _, created = unpack_ingestion_result(
            ingestion_result
        )

    except Exception as exc:
        add_error(
            result,
            url=page.final_url,
            stage="ingestion",
            error=exc,
        )

        return False

    result.articles_fetched += 1

    if created:
        result.articles_created += 1
    else:
        result.articles_duplicate += 1

    return True


def crawl_listing_seed(
    *,
    source: Source,
    seed: SourceSeedUrl,
    client: CrawlerHttpClient,
    result: CrawlSourceResult,
    processed_urls: set[str],
) -> None:
    try:
        seed_page = client.get_html(
            seed.url
        )
    except (
        CrawlerHttpError,
        RobotsDeniedError,
    ) as exc:
        add_error(
            result,
            url=seed.url,
            stage="seed_fetch",
            error=exc,
        )

        return

    result.seed_pages_processed += 1

    discovered_links = discover_article_links(
        html=seed_page.text,
        page_url=seed_page.final_url,
    )

    result.links_discovered += len(
        discovered_links
    )

    for link in discovered_links:
        if (
            result.articles_fetched
            >= source.max_articles_per_run
        ):
            break

        try:
            normalized_candidate = normalize_url(
                link
            )
        except ValueError:
            continue

        if normalized_candidate in processed_urls:
            continue

        processed_urls.add(
            normalized_candidate
        )

        validation = validate_source_url(
            source,
            normalized_candidate,
        )

        if not validation.is_valid:
            continue

        result.links_allowed += 1

        crawl_direct_article(
            source=source,
            client=client,
            article_url=validation.normalized_url,
            result=result,
        )


def crawl_source(
    *,
    source: Source,
) -> CrawlSourceResult:
    readiness = check_source_crawl_readiness(
        source
    )

    if not readiness.is_ready:
        raise ValueError(
            "Source belum siap dicrawl: "
            + "; ".join(readiness.errors)
        )

    result = CrawlSourceResult(
        source=source
    )

    processed_urls: set[str] = set()

    seeds = source.seed_urls.filter(
        is_active=True,
    ).order_by(
        "priority",
        "url",
    )

    with CrawlerHttpClient(
        source
    ) as client:
        for seed in seeds:
            if (
                result.articles_fetched
                >= source.max_articles_per_run
            ):
                break

            if (
                seed.seed_type
                == SourceSeedUrl.SeedType.DIRECT
            ):
                crawl_direct_article(
                    source=source,
                    client=client,
                    article_url=seed.url,
                    result=result,
                )

                continue

            if (
                seed.seed_type
                == SourceSeedUrl.SeedType.LISTING
            ):
                crawl_listing_seed(
                    source=source,
                    seed=seed,
                    client=client,
                    result=result,
                    processed_urls=processed_urls,
                )

                continue

            add_error(
                result,
                url=seed.url,
                stage="seed_type",
                error=(
                    "Seed RSS dan Sitemap belum "
                    "diproses oleh crawler HTML."
                ),
            )

    source.last_crawled_at = (
        timezone.now()
    )

    source.save(
        update_fields=[
            "last_crawled_at",
            "updated_at",
        ]
    )

    return result